package com.demo;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.mkyong.customer.dao.CustomerDAO;
import com.mkyong.customer.model.Customer;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-applicationContext.xml" })  
@TransactionConfiguration
@Transactional
public class CustomerDaoTest extends AbstractTransactionalJUnit4SpringContextTests {

	final Logger logger = LoggerFactory.getLogger(CustomerDaoTest.class);

	protected static int SIZE = 2;
	protected static Integer ID = new Integer(1);
	protected static String FIRST_NAME = "Joe";
	protected static String LAST_NAME = "Smith";
	protected static String CHANGED_LAST_NAME = "Jackson";

	@Autowired
	protected CustomerDAO customerDAO = null;

	@Test
	public void testHibernateTemplate() throws SQLException {
		List<Customer> list = customerDAO.listCustomer();
		logger.info(list.toString());
	}
	
	@Test
	public void testAdd() throws SQLException {
		Customer customer= new Customer();
		customer.setName("Sandeep");
		customer.setAddress("Bangalore");
		customer.setCreatedDate(new Date());
		
		 customerDAO.addCustomer(customer);
		logger.info(customer.toString());
	}
	

}