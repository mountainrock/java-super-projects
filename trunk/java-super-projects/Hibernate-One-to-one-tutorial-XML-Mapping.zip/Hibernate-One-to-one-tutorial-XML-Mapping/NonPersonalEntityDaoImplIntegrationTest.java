package com.hsbc.cibm.cfambit.fcrmhrr.dao.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;

import com.hsbc.cibm.cfambit.fcrmhrr.BaseIntegrationTest;
import com.hsbc.cibm.cfambit.fcrmhrr.MockUtil;
import com.hsbc.cibm.cfambit.fcrmhrr.dao.FcraCaseDao;
import com.hsbc.cibm.cfambit.fcrmhrr.helper.ServiceFactory;
import com.hsbc.cibm.cfambit.fcrmhrr.model.FcraCase;
import com.hsbc.cibm.cfambit.fcrmhrr.model.NonPersonalEntity;
import com.hsbc.cibm.cfambit.fcrmhrr.model.User;
import com.hsbc.cibm.cfambit.fcrmhrr.model.standingdata.ClientType;
import com.hsbc.cibm.cfambit.fcrmhrr.model.standingdata.Country;
import com.hsbc.cibm.cfambit.fcrmhrr.model.standingdata.Division;
import com.hsbc.cibm.cfambit.fcrmhrr.model.standingdata.IndustrySector;
import com.hsbc.cibm.cfambit.fcrmhrr.model.standingdata.RelationshipType;
import com.hsbc.cibm.cfambit.fcrmhrr.model.standingdata.RoleWithClient;

public class NonPersonalEntityDaoImplIntegrationTest extends BaseIntegrationTest {

	@Autowired
	FcraCaseDao<FcraCase> fcraCaseDao;

	private static final Log logger = LogFactory.getLog(NonPersonalEntityDaoImplIntegrationTest.class);

	@Before
	public void setUp() throws Exception {
		ServiceFactory.setApplicationContext(applicationContext);
		ServiceFactory.getAuditLogServiceInstance().initialize();
	}

	@Test
	@Rollback(false)
	public void testSave() {
		NonPersonalEntity caseEntity = MockUtil.getInstance().getMockNullNonPersonalEntity(fcraCaseDao.getHibernateTemplate().load(Country.class, 299L), fcraCaseDao.getHibernateTemplate().load(User.class, 10002285L));
		caseEntity.setIndustrySector(fcraCaseDao.getHibernateTemplate().load(IndustrySector.class, 1L));
		caseEntity.setCrimClient(MockUtil.getInstance().getCrimClient());

		caseEntity.getCrimClient().setCrimClientId(1070L);
		caseEntity.setNpEntityId(null);

		FcraCase mockCase = MockUtil.getInstance().getMockFcraCase();
			
		mockCase.setCaseEntity(caseEntity);
		caseEntity.setFcraCase(mockCase);

		mockCase.setRoleWithClient(fcraCaseDao.getHibernateTemplate().load(RoleWithClient.class, 1L));
		mockCase.setDivision(fcraCaseDao.getHibernateTemplate().load(Division.class, 1L));
		mockCase.setCountry(fcraCaseDao.getHibernateTemplate().load(Country.class, 299L));
		mockCase.setRelationshipType(fcraCaseDao.getHibernateTemplate().load(RelationshipType.class, 1L));
		mockCase.setClientType(fcraCaseDao.getHibernateTemplate().load(ClientType.class, 1L));

		fcraCaseDao.save(mockCase);
		fcraCaseDao.flush();
		
	}

}
