drop table test_employee
go
drop table test_employeedetail
go

/* EMPLOYEE table */ 
CREATE TABLE dbo.test_employee (    
	employee_id numeric(10,0) IDENTITY,    
	firstname varchar(16)    NULL,    
	lastname varchar(16)    NULL,    
	birth_date datetime NOT NULL,     
	cell_phone varchar(16)    NULL
) 

ALTER TABLE test_employee ADD CONSTRAINT test_employee_PK PRIMARY KEY (employee_id)
go


/* EMPLOYEEDETAIL table */ 
CREATE TABLE dbo.test_employeedetail (     	
	employee_detail_id numeric(10,0) IDENTITY,    
	employee_id numeric(10,0) NOT NULL,    
	street VARCHAR(50)   NULL,   
	city VARCHAR(50)   NULL,   
	state VARCHAR(50)   NULL,    
	country VARCHAR(50)  NULL
)

ALTER TABLE test_employeedetail ADD CONSTRAINT test_employeedetail_PK PRIMARY KEY (employee_detail_id)
go

GRANT ALL ON test_employee TO amlidweb
go
GRANT ALL ON test_employeedetail TO amlidweb
go