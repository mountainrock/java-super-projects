package net.viralpatel.hibernate;

import java.sql.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class OneToOneDemo{

	

	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();

		createEmployeeWithDetails(session);
		
		List<Employee> employees = session.createCriteria(Employee.class).list();
		for (Employee employee1 : employees) {
			System.out.println(employee1.getFirstname() + " , "
					+ employee1.getLastname() + ", "
					+ employee1.getEmployeeDetail());
		}
		
		session.close();

	}

	private static void createEmployeeWithDetails(Session session) {
		EmployeeDetail employeeDetail = new EmployeeDetail("10th Street", "LA", "San Francisco", "U.S." + System.currentTimeMillis());
		
		Employee employee = new Employee("Nina"+System.currentTimeMillis(), "Mayers", new Date(121212),
				"114-857-965");
		employee.setEmployeeDetail(employeeDetail);
		employeeDetail.setEmployee(employee);
		
		
		session.save(employee);
		session.flush();
		/*System.out.println("employee id "+employee.getEmployeeId());
		employeeDetail.setEmployeeId(employee.getEmployeeId());
		session.save(employeeDetail);
		session.flush();*/
		session.getTransaction().commit();
	}
}
